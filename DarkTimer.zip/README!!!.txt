Go to data\darktimer\functions\
then open darktimerwarn10.mcfunction using any text editor

You will see 540s in the last line.  Change this number to whatever you want. You can also edit the text on top to match your seconds

By default darktimer uses 1 minute as its base time, then on top of that you add more time to make whatever cycle time you need

540s = 9 minutes
plus the 1 minute base time, it means the timer will clear dropped items every 10 minutes

you can change 540s to any number of seconds you want, it then adds 1 minute base time to that and gives the total number of minutes

For example

60s = 2 minutes  (change the text on first line to this)
540s = 10 minutes  (change the text on first line to this)
1740s = 30 minutes  (change the text on first line to this)

----

Note: You will also need to change the chat box text to whatever value you change the timer to.
Simple edit the "10 minutes..."  in "A dark mage will clear dropped items in 10 minutes.."  

For example, if you are using 1740s which is 30 minutes duration,
Then your tellraw line will read as:-
tellraw @a {"text": "A dark mage will clear dropped items in 30 minutes..", "color": "red", "bold":"false"}

---

You can now also change the text for the other countdown lines such as 1 minute and 10 second announcements
Change the text in the following files for the relevant time:-

darktimerwarn10.mcfunction   - 10 minute announcement
darktimerwarn1.mcfunction    - 1 minute announcement
darktimerwarn10s.mcfunction  - 10 second announcement
darktimer.mcfunction         - immediate announcement