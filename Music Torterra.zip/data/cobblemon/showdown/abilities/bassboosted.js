{
    onBasePowerPriority: 7,
    onBasePower(basePower, attacker, defender, move) {
        if (move.flags['sound']) {
            this.debug('Bass Boosted boost');
            return this.chainModify([5325, 4096]);
        }
    },
    onSourceModifyDamage(damage, source, target, move) {
        if (move.flags['sound']) {
            this.debug('Bass Boosted weaken');
            return this.chainModify(0.5);
        }
    },
    flags: {breakable: 1},
    name: "Bass Boosted",
    rating: 3.5,
    num: 244,
}