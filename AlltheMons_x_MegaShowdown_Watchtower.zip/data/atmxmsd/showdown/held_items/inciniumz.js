{
  name: "Incinium Z",
  spritenum: 651,
  onTakeItem: false,
  zMove: "Malicious Moonsault",
  zMoveFrom: "Darkest Lariat",
  itemUser: [
    "Incineroar", 
    "Incineroar-Champion", 
    "Incineroar-Summer", 
    "Incineroar-Royal-Mask", 
    "Incineroar-Dancer", 
    "Incineroar-Pride", 
    "Incineroar-Trans-Pride", 
    "Incineroar-Ace-Pride", 
    "Incineroar-Bi-Pride", 
    "Incineroar-Pan-Pride",
    "Incineroar-Tekken",
    "Incineroar-Team-Skull"
  ],
  num: 799,
  gen: 7,
  isNonstandard: "Past",
}